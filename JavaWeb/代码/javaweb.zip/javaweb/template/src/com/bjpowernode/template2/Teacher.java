package com.bjpowernode.template2;

public class Teacher extends Person{

    public void doSome(){
        System.out.println("老师正在课堂上授课，教授学生知识");
    }

}
