package com.bjpowernode.template2;

public class Student extends Person {

    public void doSome(){
        System.out.println("学生上学，学习");
    }

}
