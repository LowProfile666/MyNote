package com.bjpowernode.javaweb.adapter;

/**
 * 对于CustomerService来说，最主要的方法是m2
 */
public class CustomerService implements MyInterface{
    @Override
    public void m1() {

    }

    @Override
    public void m2() {
        System.out.println("CustomerService's m2 method execute!");
    }

    @Override
    public void m3() {

    }

    @Override
    public void m4() {

    }

    @Override
    public void m5() {

    }

    @Override
    public void m6() {

    }

    @Override
    public void m7() {

    }

    @Override
    public void core() {

    }
}
