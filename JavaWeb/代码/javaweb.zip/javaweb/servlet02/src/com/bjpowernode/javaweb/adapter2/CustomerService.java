package com.bjpowernode.javaweb.adapter2;

public class CustomerService extends CustomerAdapter{
    @Override
    public void m2() {

    }
}
