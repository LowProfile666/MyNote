package com.bjpowernode.javaweb.adapter2;

public class UserService extends UserAdapter {
    @Override
    public void core() {

    }
}
