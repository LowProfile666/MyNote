package com.bjpowernode.javaweb.adapter;

/**
 * 对于UserService来说，core方法是最主要的方法。
 */
public class UserService implements MyInterface{
    @Override
    public void m1() {

    }

    @Override
    public void m2() {

    }

    @Override
    public void m3() {

    }

    @Override
    public void m4() {

    }

    @Override
    public void m5() {

    }

    @Override
    public void m6() {

    }

    @Override
    public void m7() {

    }

    @Override
    public void core() {
        System.out.println("UserService's core method execute!");
    }
}
