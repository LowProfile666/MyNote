package com.bjpowernode.javaweb.adapter2;

import com.bjpowernode.javaweb.adapter.MyInterface;

// UserService类的适配器。
public abstract class UserAdapter implements MyInterface {
    @Override
    public void m1() {

    }

    @Override
    public void m2() {

    }

    @Override
    public void m3() {

    }

    @Override
    public void m4() {

    }

    @Override
    public void m5() {

    }

    @Override
    public void m6() {

    }

    @Override
    public void m7() {

    }

    public abstract void core();
}
