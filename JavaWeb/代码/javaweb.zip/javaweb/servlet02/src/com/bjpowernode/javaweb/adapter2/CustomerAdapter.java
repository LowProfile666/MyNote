package com.bjpowernode.javaweb.adapter2;

import com.bjpowernode.javaweb.adapter.MyInterface;

/**
 * CustomerService专用的适配器。
 */
public abstract class CustomerAdapter implements MyInterface {
    @Override
    public void m1() {

    }

    public abstract void m2() ;

    @Override
    public void m3() {

    }

    @Override
    public void m4() {

    }

    @Override
    public void m5() {

    }

    @Override
    public void m6() {

    }

    @Override
    public void m7() {

    }

    @Override
    public void core() {

    }
}
