package com.powernode.threadlocal;

public class Connection {
}
